# TranscribirAudio

**TranscribirAudio** es un módulo de Jarvis diseñado para la transcripción eficiente de audios, utilizando herramientas  como **FFmpeg** y otros motores de reconocimiento de voz. Su propósito es facilitar la recopilación de datos para el entrenamiento de inteligencia artificial.

## 📌 Requisitos
Antes de ejecutar **TranscribirAudio**, asegúrate de tener instalado:

- Python 3.8+
- FFmpeg
- Dependencias en `requirements.txt`

## 📦 Instalación

1. Clona el repositorio:
   ```sh
   git clone https://github.com/Jordan-Iralde/TranscribirAudio.git
   ```
2. Accede al directorio:
   ```sh
   cd TranscribirAudio
   ```
3. Instala las dependencias:
   ```sh
   pip install -r requirements.txt
   ```
4. Verifica que FFmpeg esté instalado:
   ```sh
   ffmpeg -version
   ```

## 🛠️ Uso

### 1️⃣ Transcribir un archivo de audio
```sh
python transcribir.py --input audio.mp3 --output texto.txt
```

### 2️⃣ Configurar opciones de transcripción
```sh
python transcribir.py --config
```

### 3️⃣ Integración con Jarvis
```sh
python transcribir.py --jarvis
```

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Para colaborar:


📢 ¡Dale ⭐ al repositorio si te ha sido útil!
